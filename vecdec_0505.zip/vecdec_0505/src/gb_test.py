import subprocess
import time


def run_vecdec(outfile, P_values, matX, matZ,d,mode="1.0",nfail=100,lerr=0,maxosd=100,C_ntot=100):
    with open(outfile, 'a') as f:
        for P in P_values:
            # Prepare the command with the calculated ntot
            ntot =1e6
            command = [
                './vecdec',
                'debug=0',
                f'finH={matX}',
                f'finG={matZ}',
                f'useP={P}',
                f'mode={mode}',
                f'lerr={lerr}',
                f'maxosd={maxosd}',
                f'nfail={nfail}',
                f'ntot={int(ntot)}'
            ]

            # Write the initial part of the line
            f.write(f"{P} ")

            # Record start time
            start_time = time.time()

            # Run the command
            result = subprocess.run(command, capture_output=True, text=True)

            # Calculate the elapsed time
            elapsed_time = time.time() - start_time

            # Write the result and the time to the file
            f.write(f"{result.stdout} {result.stderr} ")
            print(f"{matX} P={P} Time taken: {elapsed_time:.2f} seconds\n")

# Array of values for useP
P_values = [ 0.01 ]
P_values=P_values[::-1]


matX = f'./parityChecks/GB_26_w8_X.mtx'
matZ = f'./parityChecks/GB_26_w8_Z.mtx'
outfile = f'./data/test.out'
run_vecdec(outfile=outfile, P_values=P_values, matX=matX, matZ=matZ,mode="1",d=5,nfail=10000,lerr=2,maxosd=100,C_ntot=1)




print("Script execution completed.")

