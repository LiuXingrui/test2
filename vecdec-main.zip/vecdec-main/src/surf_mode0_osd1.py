import subprocess
import time


def run_vecdec(outfile, P_values, matX, matZ,d,mode="1.0",nfail=100,lerr=0,maxosd=100):
    with open(outfile, 'a') as f:
        for P in P_values:
            # Prepare the command with the calculated ntot
            ntot =  1.0 / (P**((d+1)/2))
            ntot=1e8
            command = [
                './vecdec',
                'debug=0',
                f'finH={matX}',
                f'finG={matZ}',
                f'useP={P}',
                f'mode={mode}',
                f'lerr={lerr}',
                f'maxosd={maxosd}',
                f'nfail={nfail}',
                f'ntot={int(ntot)}'
            ]

            # Write the initial part of the line
            f.write(f"{P} ")

            # Record start time
            start_time = time.time()

            # Run the command
            result = subprocess.run(command, capture_output=True, text=True)

            # Calculate the elapsed time
            elapsed_time = time.time() - start_time

            # Write the result and the time to the file
            f.write(f"{result.stdout} {result.stderr} ")
            print(f"{matX} P={P} Time taken: {elapsed_time:.2f} seconds\n")

# Array of values for useP
P_values = [0.004, 0.005656, 0.008, 0.011312, 0.016, 0.022624, 0.032, 0.045249, 0.064, 0.090496,  0.128, 0.181 ]
P_values=P_values[::-1]
P_values=[0.004]
d_list=[7]

for d in d_list:
	matX = f'./parityChecks/rot_surf_Hx_d{d}.mtx'
	matZ = f'./parityChecks/rot_surf_Hz_d{d}.mtx'
	outfile = f'./data/surf_d{d}_mode1.0_osd2.out'
	run_vecdec(outfile=outfile, P_values=P_values, matX=matX, matZ=matZ,mode="1.0",d=d,nfail=100,lerr=2,maxosd=100)
# Open the output file

print("Script execution completed.")

