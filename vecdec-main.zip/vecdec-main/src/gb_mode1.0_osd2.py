import subprocess
import time


def run_vecdec(outfile, P_values, matX, matZ,d,mode="1.0",nfail=100,lerr=0,maxosd=100,C_ntot=100):
    with open(outfile, 'a') as f:
        for P in P_values:
            # Prepare the command with the calculated ntot
            ntot = 1.0 / (C_ntot*P**((d+1)/2))
            command = [
                './vecdec',
                'debug=0',
                f'finH={matX}',
                f'finG={matZ}',
                f'useP={P}',
                f'mode={mode}',
                f'lerr={lerr}',
                f'maxosd={maxosd}',
                f'nfail={nfail}',
                f'ntot={int(ntot)}'
            ]

            # Write the initial part of the line
            f.write(f"{P} ")

            # Record start time
            start_time = time.time()

            # Run the command
            result = subprocess.run(command, capture_output=True, text=True)

            # Calculate the elapsed time
            elapsed_time = time.time() - start_time

            # Write the result and the time to the file
            f.write(f"{result.stdout} {result.stderr} ")
            print(f"{matX} P={P} Time taken: {elapsed_time:.2f} seconds\n")

# Array of values for useP
P_values = [0.004, 0.005656, 0.008, 0.011312, 0.016, 0.022624, 0.032, 0.045249, 0.064, 0.090496,  0.128, 0.181 ]
P_values=P_values[::-1]


matX = f'./parityChecks/GB_26_w6_X.mtx'
matZ = f'./parityChecks/GB_26_w6_Z.mtx'
outfile = f'./data/GB_26_w6_mode1_osd2.out'
run_vecdec(outfile=outfile, P_values=P_values, matX=matX, matZ=matZ,mode="1",d=5,nfail=100,lerr=222,maxosd=100,C_ntot=1)

matX = f'./parityChecks/GB_26_w8_X.mtx'
matZ = f'./parityChecks/GB_26_w8_Z.mtx'
outfile = f'./data/GB_26_w8_mode1_osd2.out'
run_vecdec(outfile=outfile, P_values=P_values, matX=matX, matZ=matZ,mode="1",d=6,nfail=100,lerr=1,maxosd=100,C_ntot=1)

matX = f'./parityChecks/GB_58_w6_X.mtx'
matZ = f'./parityChecks/GB_58_w6_Z.mtx'
outfile = f'./data/GB_58_w6_mode1_osd2.out'
run_vecdec(outfile=outfile, P_values=P_values, matX=matX, matZ=matZ,mode="1",d=9,nfail=100,lerr=1,maxosd=100,C_ntot=10)

matX = f'./parityChecks/GB_58_w8_X.mtx'
matZ = f'./parityChecks/GB_58_w8_Z.mtx'
outfile = f'./data/GB_58_w8_mode1_osd2.out'
run_vecdec(outfile=outfile, P_values=P_values, matX=matX, matZ=matZ,mode="1",d=10,nfail=100,lerr=1,maxosd=100,C_ntot=10)


matX = f'./parityChecks/GB_74_w6_X.mtx'
matZ = f'./parityChecks/GB_74_w6_Z.mtx'
outfile = f'./data/GB_74_w6_mode1_osd2.out'
run_vecdec(outfile=outfile, P_values=P_values, matX=matX, matZ=matZ,mode="1",d=11,nfail=100,lerr=1,maxosd=100,C_ntot=100)

matX = f'./parityChecks/GB_74_w8_X.mtx'
matZ = f'./parityChecks/GB_74_w8_Z.mtx'
outfile = f'./data/GB_74_w8_mode1_osd2.out'
run_vecdec(outfile=outfile, P_values=P_values, matX=matX, matZ=matZ,mode="1",d=12,nfail=100,lerr=1,maxosd=100,C_ntot=100)



print("Script execution completed.")

