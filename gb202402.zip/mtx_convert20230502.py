import os
os.system("./conv.out GB_22_w4_X.mtx  GB_22_w4_X ")
os.system("./conv.out GB_22_w4_Z.mtx  GB_22_w4_Z ")

os.system("./conv.out GB_38_w4_X.mtx  GB_38_w4_X")
os.system("./conv.out GB_38_w4_Z.mtx  GB_38_w4_Z ")

os.system("./conv.out GB_74_w4_X.mtx  GB_74_w4_X ")
os.system("./conv.out GB_74_w4_Z.mtx  GB_74_w4_Z ")

#######################################################

os.system("./conv.out GB_22_w6_X.mtx  GB_22_w6_X ")
os.system("./conv.out GB_22_w6_Z.mtx  GB_22_w6_Z ")

os.system("./conv.out GB_38_w6_X.mtx  GB_38_w6_X")
os.system("./conv.out GB_38_w6_Z.mtx  GB_38_w6_Z ")

os.system("./conv.out GB_74_w6_X.mtx  GB_74_w6_X ")
os.system("./conv.out GB_74_w6_Z.mtx  GB_74_w6_Z ")
 
#######################################################3

os.system("./conv.out GB_22_w8_X.mtx  GB_22_w8_X ")
os.system("./conv.out GB_22_w8_Z.mtx  GB_22_w8_Z ")

os.system("./conv.out GB_38_w8_X.mtx  GB_38_w8_X")
os.system("./conv.out GB_38_w8_Z.mtx  GB_38_w8_Z ")

os.system("./conv.out GB_74_w8_X.mtx  GB_74_w8_X ")
os.system("./conv.out GB_74_w8_Z.mtx  GB_74_w8_Z ")